class SavingsAccount {

    public static double annualInterestRate;
    private double savingsBalance;

    public SavingsAccount() {
        this(0.0, 0.0);  // Call the other constructor with default values
    }

    public SavingsAccount(double intRat, double savBal) {
        annualInterestRate = intRat;
        savingsBalance = savBal;
    }

    public double calculateMonthlyInterest() {
        double monthlyInterest = savingsBalance * (annualInterestRate / 12);
        savingsBalance += monthlyInterest;
        return monthlyInterest;
    }

    public static void modifyInterestRate(double newInterestRate) {
        annualInterestRate = newInterestRate;
    }

    public void setSavingsBalance(double newBal) {
        savingsBalance = newBal;
    }

    public double getSavingsBalance() {
        return savingsBalance;
    }

    public double getAnnualInterestRate() {
        return annualInterestRate;
    }
}

// Test program
public class SavingsAccountTest {
    public static void main(String[] args) {
        SavingsAccount saver1 = new SavingsAccount(0.04, 2000.0);
        SavingsAccount saver2 = new SavingsAccount(0.04, 3000.0);

        System.out.println("Initial balances:");
        System.out.println("Saver1: " + saver1.getSavingsBalance());
        System.out.println("Saver2: " + saver2.getSavingsBalance());

        System.out.println("\nMonth 1 (Interest rate = 4%):");
        saver1.calculateMonthlyInterest();
        saver2.calculateMonthlyInterest();
        System.out.println("Saver1: " + saver1.getSavingsBalance());
        System.out.println("Saver2: " + saver2.getSavingsBalance());

        SavingsAccount.modifyInterestRate(0.05);

        System.out.println("\nMonth 2 (Interest rate = 5%):");
        saver1.calculateMonthlyInterest();
        saver2.calculateMonthlyInterest();
        System.out.println("Saver1: " + saver1.getSavingsBalance());
        System.out.println("Saver2: " + saver2.getSavingsBalance());
    }
}
