class Car {
    int speed;
    double regularPrice;
    String color;

    Car(int speed, double regularPrice, String color) {
        this.speed = speed;
        this.regularPrice = regularPrice;
        this.color = color;
    }

    double getSalePrice() {
        return regularPrice; // No discount for the base Car class
    }
}

class Truck extends Car {
    int weight;

    Truck(int speed, double regularPrice, String color, int weight) {
        super(speed, regularPrice, color);
        this.weight = weight;
    }

    @Override
    double getSalePrice() {
        double discount = weight > 2000 ? 0.1 : 0.2;
        return regularPrice * (1 - discount);
    }
}

class Ford extends Car {
    int year;
    int manufacturerDiscount;

    Ford(int speed, double regularPrice, String color, int year, int manufacturerDiscount) {
        super(speed, regularPrice, color);
        this.year = year;
        this.manufacturerDiscount = manufacturerDiscount;
    }

    @Override
    double getSalePrice() {
        return regularPrice - manufacturerDiscount;
    }
}

class Sedan extends Car {
    int length;

    Sedan(int speed, double regularPrice, String color, int length) {
        super(speed, regularPrice, color);
        this.length = length;
    }

    @Override
    double getSalePrice() {
        double discount = length > 20 ? 0.05 : 0.1;
        return regularPrice * (1 - discount);
    }
}

class MyOwnAutoShop {
    public static void main(String[] args) {
        // Create instances of Sedan, Ford, and Car classes
        Sedan sedan = new Sedan(150, 25000, "Red", 22);
        Ford ford1 = new Ford(180, 30000, "Blue", 2023, 2000);
        Ford ford2 = new Ford(200, 35000, "Black", 2022, 1500);
        Car car = new Car(120, 20000, "Silver");

        // Display the sale prices
        System.out.println("Sedan sale price: " + sedan.getSalePrice());
        System.out.println("Ford 1 sale price: " + ford1.getSalePrice());
        System.out.println("Ford 2 sale price: " + ford2.getSalePrice());
        System.out.println("Car sale price: " + car.getSalePrice());
    }
}
