import java.util.Scanner;

public class grade{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Enter student registration number (or 'quit' to exit): ");
            String regNo = scanner.nextLine();
            if (regNo.equalsIgnoreCase("quit")) {
                break;
            }

            int quizScore;
            do {
                System.out.print("Enter quiz score (out of 10): ");
                quizScore = scanner.nextInt();
                scanner.nextLine(); // Consume newline character
                if (quizScore > 10) {
                    System.out.println("Invalid input. Quiz score cannot exceed 10.");
                }
            } while (quizScore > 10);

            int assignmentScore;
            do {
                System.out.print("Enter assignment score (out of 10): ");
                assignmentScore = scanner.nextInt();
                scanner.nextLine();
                if (assignmentScore > 10) {
                    System.out.println("Invalid input. Assignment score cannot exceed 10.");
                }
            } while (assignmentScore > 10);

            int midtermScore;
            do {
                System.out.print("Enter midterm exam score (out of 20): ");
                midtermScore = scanner.nextInt();
                scanner.nextLine();
                if (midtermScore > 20) {
                    System.out.println("Invalid input. Midterm score cannot exceed 20.");
                }
            } while (midtermScore > 20);

            int finalScore;
            do {
                System.out.print("Enter final exam score (out of 60): ");
                finalScore = scanner.nextInt();
                scanner.nextLine();
                if (finalScore > 60) {
                    System.out.println("Invalid input. Final exam score cannot exceed 60.");
                }
            } while (finalScore > 60);

            int totalScore = quizScore + assignmentScore + midtermScore + finalScore;
            String grade = totalScore > 55 ? "Pass" : "Fail";

            System.out.println("Student " + regNo + "'s grade: " + grade);
        }

        System.out.println("Program ended.");
    }
}
