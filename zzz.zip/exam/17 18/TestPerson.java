abstract class Person {
    private String name;
    private String NICNum;

    public Person(String name, String NICNum) {
        this.name = name;
        this.NICNum = NICNum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNICNum() {
        return NICNum;
    }

    public void setNICNum(String NICNum) {
        this.NICNum = NICNum;
    }

    @Override
    public String toString() {
        return "Person: " + name;
    }
}

class Student extends Person {
    private String regNo;
    private String status;
    private float gpa;

    public Student(String name, String NICNum, String regNo, String status, float gpa) {
        super(name, NICNum);
        this.regNo = regNo;
        this.status = status;
        this.gpa = gpa;
    }

    // Getters and setters for regNo, status, and gpa

    @Override
    public String toString() {
        return "Student: " + name;
    }
}

class Employee extends Person {
    private String empNo;
    private int hireYear;
    private String dept;
    private double salary;

    public Employee(String name, String NICNum, String empNo, int hireYear, String dept, double salary) {
        super(name, NICNum);
        this.empNo = empNo;
        this.hireYear = hireYear;
        this.dept = dept;
        this.salary = salary;
    }

    // Getters and setters for empNo, hireYear, dept, and salary

    @Override
    public String toString() {
        return "Employee: " + name;
    }
}

public class Testperson {
    public static void main(String[] args) {
        Student student = new Student("John Doe", "123456789V", "S12345", "2nd year", 3.5f);
        Employee employee = new Employee("Jane Smith", "987654321V", "E67890", 2020, "IT", 50000);

        System.out.println(student); // Output: Student: John Doe
        System.out.println(employee); // Output: Employee: Jane Smith
    }
}
