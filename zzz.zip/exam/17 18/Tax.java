import java.util.Scanner;

public class Tax {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your gross salary: ");
        double grossSalary = scanner.nextDouble();

        System.out.print("Enter your total savings: ");
        double totalSavings = scanner.nextDouble();

        double tax = taxCalculator(grossSalary, totalSavings);

        System.out.println("Your calculated tax is: Rs. " + tax);
    }

    public static double taxCalculator(double grossSalary, double totalSavings) {
        double taxableIncome = grossSalary;

        if (totalSavings > 100000) {
            taxableIncome -= 100000; // Deduct maximum savings
            totalSavings -= 100000; // Update remaining savings
        } else {
            taxableIncome -= totalSavings; // Deduct actual savings
        }

        double tax = 0;

        if (taxableIncome > 500000) {
            tax += (taxableIncome - 500000) * 0.3; // Slab 3: 30% tax
            taxableIncome = 500000;
        }

        if (taxableIncome > 200000) {
            tax += (taxableIncome - 200000) * 0.2; // Slab 2: 20% tax
            taxableIncome = 200000;
        }

        if (taxableIncome > 100000) {
            tax += (taxableIncome - 100000) * 0.1; // Slab 1: 10% tax
        }

        return tax;
    }
}
