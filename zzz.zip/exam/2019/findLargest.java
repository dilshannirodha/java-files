import java.util.Scanner;

public class findLargest{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter array size:=> ");
        int size = scanner.nextInt();

        int[] arr = new int[size];

        System.out.println("Enter the elements:");
        for (int i = 0; i < size; i++) {
            System.out.print("Element " + (i + 1) + ":=> ");
            arr[i] = scanner.nextInt();
        }

        int temp = 0;  
         for(int i=0; i < size; i++){  
                 for(int j=1; j < (size-i); j++){  
                          if(arr[j-1] > arr[j]){   
                                 temp = arr[j-1];  
                                 arr[j-1] = arr[j];  
                                 arr[j] = temp;  
                         }  
                          
                 }
		 }
		 int largest = arr[size-1];
		 int secondLargest = arr[size-2];
		 
		 System.out.println("Largest element is "+ largest);
		 System.out.println("Second largest is " + secondLargest );
		 
}
}
