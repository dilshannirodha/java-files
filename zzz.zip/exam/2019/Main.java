class Publication {
    private String title;
    private double price;

    public Publication(String title, double price) {
        this.title = title;
        this.price = price;
    }

    public void getData() {
        System.out.println("Title: " + title);
        System.out.println("Price: " + price);
    }

    public void print() {
        System.out.println("Publication Details:");
        getData();
    }
}

interface Book {
    public int getAccessionNumber();

    public default void getData() {
        System.out.println("Accession Number: " + getAccessionNumber());
    }

    public default void print() {
        System.out.println("Book Details:");
        getData();
    }
}

interface Magazine {
    public int getVolumeNumber();

    public default void getData() {
        System.out.println("Volume Number: " + getVolumeNumber());
    }

    public default void print() {
        System.out.println("Magazine Details:");
        getData();
    }
}

class Journal extends Publication implements Book, Magazine {
    private String journalName;

    public Journal(String title, double price, String journalName) {
        super(title, price);
        this.journalName = journalName;
    }

    @Override
    public int getAccessionNumber() {
        // Implement accession number logic for Journal
        return 0; // Replace with appropriate logic
    }

    @Override
    public int getVolumeNumber() {
        // Implement volume number logic for Journal
        return 0; // Replace with appropriate logic
    }

    @Override
    public void print() {
        System.out.println("Journal Details:");
        super.print(); // Call base class print()
        System.out.println("Journal Name: " + journalName);
    }
}

public class Main {
    public static void main(String[] args) {
        Journal journal1 = new Journal("Nature", 19.95, "Nature Journal");
        Journal journal2 = new Journal("Science", 25.00, "Science Journal");
        Journal journal3 = new Journal("Cell", 22.50, "Cell Journal");
        Journal journal4 = new Journal("The Lancet", 30.00, "The Lancet Journal");
        Journal journal5 = new Journal("New England Journal of Medicine", 35.00, "NEJM");

        journal1.getData();
        journal1.print();

        // Similarly for other journal objects
    }
}
