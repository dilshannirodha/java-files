class Hotel {

    private String name;
    private int stars;
    private int availableRooms; // Instance variable for available rooms

    public Hotel(String name, int stars, int singleRooms, int doubleRooms, int tripleRooms) {
        this.name = name;
        this.stars = stars;
        this.availableRooms = singleRooms + doubleRooms + tripleRooms;
    }

    public String getName() {
        return name;
    }

    public int getStars() {
        return stars;
    }

    public int getAvailableRooms() {
        return availableRooms;
    }

    public void hote() {
        System.out.println("Welcome to " + name + ", a " + stars + "-star hotel!");
    }

    public void decreaseAvailableRooms() {
        availableRooms--;
    }

    public void increaseAvailableRooms() {
        availableRooms++;
    }
}

class Room {

    private int id;
    private double price;
    private String type; // "single", "double", "triple"

    public Room(int id, String type) {
        this.id = id;
        this.type = type;
        setPrice(type);
    }

    public int getId() {
        return id;
    }

    public double getPrice() {
        return price;
    }

    public String getType() {
        return type;
    }

    public void setPrice(String type) {
        switch (type) {
            case "single":
                price = 2000.00;
                break;
            case "double":
                price = 3500.00;
                break;
            case "triple":
                price = 5000.00;
                break;
        }
    }

    public void displayInfo() {
        System.out.println("Room " + id + ": " + type + " room, price per day: LKR " + price);
    }
}

class Resident {

    private int id;
    private String name;
    private int daysStaying;
    private Room room;
    private double finalCost;

    public Resident(int id, String name, int daysStaying) throws Days_Reserved_Exception {
        if (daysStaying < 1) {
            throw new Days_Reserved_Exception("Invalid number of days");
        }
        this.id = id;
        this.name = name;
        this.daysStaying = daysStaying;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getDaysStaying() {
        return daysStaying;
    }

    public Room getRoom() {
        return room;
    }

    public double getFinalCost() {
        return finalCost;
    }

    public void setRoom(Room room, int daysStaying) {
        this.room = room;
        this.finalCost = room.getPrice() * daysStaying;
        room.displayInfo();
    }

    public void displayInfo() {
        System.out.println("Resident " + id + ": " + name + ", staying for " + daysStaying + " days");
        if (room != null) {
            room.displayInfo();
            System.out.println("Total cost: LKR " + finalCost);
        } else {
            System.out.println("No room assigned yet.");
        }
    }
}

class Days_Reserved_Exception extends Exception {

    public Days_Reserved_Exception(String message) {
        super(message);
    }
}

public class HMS{

    public static void main(String[] args) {

        Hotel grandPalace = new Hotel("Grand Palace", 5, 1, 1, 1);
        grandPalace.hote();

        Room room1 = new Room(1, "single");
        Room room2 = new Room(2, "double");
        Room room3 = new Room(3, "triple");

        try {
            Resident resident1 = new Resident(1, "John Smith", 3);
            resident1.setRoom(room1, 3);
            grandPalace.decreaseAvailableRooms();
            System.out.println("Available rooms after John's booking: " + grandPalace.getAvailableRooms());
        } catch (Days_Reserved_Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
