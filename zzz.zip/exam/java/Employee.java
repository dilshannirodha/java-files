import java.util.Scanner;

public class Employee {
    String name;
    int emp_no;
    double salary;

    public static void main(String[] args) {
        Employee[] employees = new Employee[1];
        for (int i=0; i<employees.length; i++) {
            employees[i] = new Employee();
            employees[i].getValues();
        }
        for (int i=0; i<employees.length; i++) {
            employees[i].displayValues();
        }
    }

    public void getValues() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter employee name: ");
        name = sc.nextLine();
        System.out.print("Enter employee number: ");
        emp_no = sc.nextInt();
        System.out.print("Enter employee salary: ");
        salary = sc.nextDouble();
    }

    public void displayValues() {
        System.out.println("Name: " + name);
        System.out.println("Employee number: " + emp_no);
        System.out.println("Salary: " + salary);
        System.out.println();
    }
}