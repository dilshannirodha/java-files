
import java.util.Scanner;

public class Student{

    static Scanner sc = new Scanner(System.in);
    static String std_Name;
    static int index_No;
    static double marks;

    public static void main(String[] args) {

        System.out.print("Number of students : ");
        int amount = sc.nextInt();

        int score = 0;
        while(score<amount){
            Read_data();
            Display_data();
            System.out.println("");
            score++;
        }
    }

    public static void Read_data(){
        
        System.out.print("Enter student Name : ");
        std_Name = sc.next();

        System.out.print("Enter student Index No : ");
        index_No = sc.nextInt();

        System.out.print("Enter student Marks: ");
        marks = sc.nextDouble();
    }

    public static void Display_data(){
        System.out.println("\nName = " + std_Name);
        System.out.println("Index No = " + index_No);
        System.out.println("Marks = " + marks);
    }
}