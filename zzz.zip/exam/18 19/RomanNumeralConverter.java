class RomanNumeralConverter {

    private static final char[] romanSymbols = {'I', 'V', 'X', 'L', 'C', 'D', 'M'};
    private static final int[] romanValues = {1, 5, 10, 50, 100, 500, 1000};

    public static int romanToInteger(String romanNumeral) {
        int result = 0;
        int i = 0;
        while (i < romanNumeral.length()) {
            char currentChar = romanNumeral.charAt(i);
            int currentValue = getRomanValue(currentChar);

            if (i < romanNumeral.length() - 1) {
                int nextValue = getRomanValue(romanNumeral.charAt(i + 1));
                if (currentValue < nextValue) {
                    result += (nextValue - currentValue);
                    i += 2; // Skip the next character
                } else {
                    result += currentValue;
                    i++;
                }
            } else {
                result += currentValue;
                i++;
            }
        }
        return result;
    }

    public static String integerToRoman(int number) {
        StringBuilder roman = new StringBuilder();
        int remaining = number;
        for (int i = romanValues.length - 1; i >= 0; i--) {
            int value = romanValues[i];
            while (remaining >= value) {
                roman.append(romanSymbols[i]);
                remaining -= value;
            }
        }
        return roman.toString();
    }

    private static int getRomanValue(char symbol) {
        for (int i = 0; i < romanSymbols.length; i++) {
            if (symbol == romanSymbols[i]) {
                return romanValues[i];
            }
        }
        return -1; // Invalid symbol
    }

    public static void main(String[] args) {
        System.out.println(romanToInteger("MCMXCIV"));  // Output: 1994
        System.out.println(integerToRoman(3549));  // Output: MMMDXLIX
    }
}
