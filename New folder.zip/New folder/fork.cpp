#include <iostream>
#include <unistd.h> 


void childProcess1() {
    std::cout << "This is child process 1. PID: " << getpid() << std::endl;
}

void childProcess2() {
    std::cout << "This is child process 2. PID: " << getpid() << std::endl;
}

void childProcess3() {
    std::cout << "This is child process 3. PID: " << getpid() << std::endl;
}

int main() {
    const int NUM_CHILDREN = 3; // Number of child processes to create
    pid_t pid; // Variable to store process ID

    for (int i = 0; i < NUM_CHILDREN; ++i) {
        pid = fork();

        if (pid < 0) { // Error occurred
            std::cerr << "Fork failed";
            return 1;
        } else if (pid == 0) { // Child process
            switch (i) {
                case 0:
                    childProcess1();
                    break;
                case 1:
                    childProcess2();
                    break;
                case 2:
                    childProcess3();
                    break;
                default:
                    std::cerr << "Invalid child process number" << std::endl;
                    return 1;
            }
            return 0; // Child process should exit after execution
        } else { // Parent process
            std::cout << "Parent process. PID: " << getpid() << ", Child PID: " << pid << std::endl;
        }
    }

    return 0;
}
